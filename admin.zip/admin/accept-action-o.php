<center>
<?php
include 'config.php';
  session_start();

  
if (isset($_GET['edit_id'])) {
  
    $sql = "SELECT * FROM transaction where transaction_id =" .$_GET['edit_id'];
    $result = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($result);
  }

  if(isset($_POST['accept']))
  {

    $start = $_POST['start'];
    $returned = $_POST['returned'];
    $end = $_POST['end'];
    $status = $_POST['status'];
    $qty_return = $_POST['qty_return'];

    $update = "UPDATE transaction SET status = '$status'  where transaction_id=". $_GET['edit_id'];
    $up = mysqli_query($con, $update);
    if (!isset($sql)){
        die ("Error $sql" .mysqli_connect());
    }
    else {
        header("location:accept-action-o.php");
    }


    }
?>

</center>
