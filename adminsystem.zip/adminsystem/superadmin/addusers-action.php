<center>
<?php
include 'config.php';

  if(isset($_POST['adduser']))
  {


    $user = $_POST['user'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $role = $_POST['role'];
    $status = $_POST['status'];
    $pass = $_POST['pass'];

    $sql = "INSERT INTO `users`(`first_name`, `last_name`, `role`,`status`, `user_name`, `password`) VALUES ('$firstname','$lastname','$role','$status','$user','$pass')";
    $result = mysqli_query($con,$sql);

    if($result) {
echo 'User Added';
    }else{
      echo 'User, Not Added';
    }


    header("refresh:1;url=addusers.php");

    }
?>

</center>
