-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2018 at 01:29 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `weblab`
--

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `equipment_id` int(11) NOT NULL,
  `equipment_code` varchar(255) NOT NULL,
  `equipment_name` varchar(45) NOT NULL,
  `equipment_desc` varchar(45) NOT NULL,
  `equipment_pic` blob NOT NULL,
  `equipment_quantity` int(200) NOT NULL,
  `equipment_price` decimal(6,2) NOT NULL,
  `category` enum('Wheel Loaders','Loader Backhoes','Dozers','Skid Steers','Cranes','Compactors','Excavators','Asphalt Paving') NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equipment_id`, `equipment_code`, `equipment_name`, `equipment_desc`, `equipment_pic`, `equipment_quantity`, `equipment_price`, `category`, `added_date`) VALUES
(1, '001', 'BullDozer', 'Bull Dozer Description', 0x446f7a65722c203131302068702e6a7067, 10, '2500.00', 'Dozers', '2018-12-09 19:38:57'),
(2, '002', 'The Crane', 'Carry Deck Crane Description', 0x4361727279204465636b204372616e652c20313520546f6e2e6a7067, 10, '3200.00', 'Cranes', '2018-12-09 19:39:37'),
(4, '004', 'Backhoe loader', 'this is backhoe', 0x4261636b686f65204c6f616465722c2036302d39302068702c2034574420457874656e6465642c204361622e6a7067, 4, '9999.99', 'Loader Backhoes', '2018-12-10 11:55:52'),
(5, '005', 'Excavator', 'this excavator', 0x457863617661746f722c2032352c3030302d32392c303030206c62732e6a7067, 4, '9999.99', 'Excavators', '2018-12-10 13:25:44');

-- --------------------------------------------------------

--
-- Stand-in structure for view `quantity`
-- (See below for the actual view)
--
CREATE TABLE `quantity` (
`quantity` bigint(67)
,`equipment_id` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `date_returned` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `end_date` date NOT NULL,
  `status` enum('pending','denied','ongoing','completed') NOT NULL,
  `quantity_rented` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `equipment_id`, `user_id`, `start_date`, `date_returned`, `end_date`, `status`, `quantity_rented`) VALUES
(1, 1, 1, '2018-12-02', '2018-12-09 15:29:45', '2018-12-04', 'completed', 3),
(2, 2, 2, '2018-12-05', '2018-12-09 18:21:19', '2018-12-28', 'completed', 4),
(3, 3, 3, '2018-12-05', '2018-12-09 15:00:00', '2018-12-28', 'pending', 7);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` enum('Activate','Deactivate','Pending') NOT NULL DEFAULT 'Pending',
  `role` enum('client','admin','superadmin','') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `user_name`, `password`, `status`, `role`) VALUES
(1, 'ojojy', 'dela cruz', 'admin', 'admin1', 'Activate', 'superadmin'),
(2, 'Clark', 'Kent', 'Superman', 'superadmin', 'Activate', 'admin');

-- --------------------------------------------------------

--
-- Structure for view `quantity`
--
DROP TABLE IF EXISTS `quantity`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `quantity`  AS  select (`equipment`.`equipment_quantity` - `transaction`.`quantity_rented`) AS `quantity`,`equipment`.`equipment_id` AS `equipment_id` from (`equipment` join `transaction` on((`equipment`.`equipment_id` = `transaction`.`equipment_id`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equipment_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
